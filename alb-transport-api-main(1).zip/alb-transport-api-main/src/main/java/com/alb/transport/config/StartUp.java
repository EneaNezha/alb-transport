package com.alb.transport.config;

import com.alb.transport.repository.TerminalRepository;
import com.alb.transport.services.RouteService;
import com.alb.transport.services.TerminalService;
import com.alb.transport.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class StartUp implements CommandLineRunner {
    private final TerminalService terminalService;
    private final UserService userService;
    private final RouteService routeService;

    @Override
    public void run(String... args) throws Exception {
        terminalService.initDefaultData();
        userService.initializeDefaultUsers();
        routeService.initDefaultData();
    }
}
