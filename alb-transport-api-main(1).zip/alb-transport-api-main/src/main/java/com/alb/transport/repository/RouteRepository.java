package com.alb.transport.repository;

import com.alb.transport.dto.RouteRead;
import com.alb.transport.entities.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface RouteRepository extends JpaRepository<Route, Integer> {
    Optional<Route> findByStartTerminalIdAndEndTerminalIdAndStart(int startTerminalId, int endTerminalId, LocalTime start);

    @Query("select r.id as id, r.startTerminalId as startTerminalId, r.startTerminal.city as startTerminalCity, r.startTerminal.address as startTerminalAddress, r.endTerminalId as endTerminaId, r.endTerminal.city as endTerminalCity, r.endTerminal.address as endTerminalAddress, r.driverId as driverId, r.driver.phone as driverPhone, r.seats as seats, r.start as start, r.duration as duration, r.price as price from Route r where r.start > :startTime and (:fromCity is null or lower(r.startTerminal.city) = lower(:fromCity)) ")
    List<RouteRead> getUpComingByFromStartRouteName(@Param("startTime") LocalTime startTime, @Param("fromCity") String fromCity);
}
