package com.alb.transport.repository;

import com.alb.transport.entities.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface TerminalRepository extends JpaRepository<Terminal, Integer> {
    @Query("from Terminal t where t.city = :city")
    Optional<Terminal> getByCity(@Param("city") String city);
}
