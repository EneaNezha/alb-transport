package com.alb.transport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlbTransportApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlbTransportApiApplication.class, args);
	}

}
