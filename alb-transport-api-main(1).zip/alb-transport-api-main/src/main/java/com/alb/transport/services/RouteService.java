package com.alb.transport.services;

import com.alb.transport.dto.RouteRead;
import com.alb.transport.entities.Route;
import com.alb.transport.entities.Terminal;
import com.alb.transport.entities.User;
import com.alb.transport.repository.RouteRepository;
import com.alb.transport.repository.TerminalRepository;
import com.alb.transport.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RouteService {
    private final RouteRepository routeRepository;
    private final TerminalRepository terminalRepository;
    private final UserRepository userRepository;

    public List<Route> findAllRoutes() {
        return routeRepository.findAll();
    }

    public List<RouteRead> getUpComingByFromRouteName(String from) {
        return routeRepository.getUpComingByFromStartRouteName(LocalTime.now(), from);
    }

    public void initDefaultData() {
        Terminal tirana = terminalRepository.getByCity("Tirana").orElseGet(() -> createTerminal("Tirana", "RR: Terminalit Tirane"));
        Terminal pogradec = terminalRepository.getByCity("Pogradec").orElseGet(() -> createTerminal("Pogradec", "RR: Terminalit Pogradec"));
        Terminal saranda = terminalRepository.getByCity("Saranda").orElseGet(() -> createTerminal("Saranda", "RR: Terminalit Sarandes"));
        User petriti = userRepository.findByEmail("driver_1@example.com").orElseGet(() -> createUser("driver_1@example.com", "pass123"));
        User beni = userRepository.findByEmail("driver_2@example.com").orElseGet(() -> createUser("driver_2@example.com", "pass123"));

        // 1- Pogradec-Tirane 09:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(pogradec.getId(), tirana.getId(), LocalTime.of(9, 0))
                .map(o -> {
                    log.info("Pogradec-Tirane 09:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(pogradec.getId());
                    route.setEndTerminalId(tirana.getId());
                    route.setDuration(2.5);
                    route.setDriverId(petriti.getId());
                    route.setStart(LocalTime.of(9, 0));
                    route.setSeats(100);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });

        // 2- Pogradec-Tirane 12:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(pogradec.getId(), tirana.getId(), LocalTime.of(12, 0))
                .map(o -> {
                    log.info("Pogradec-Tirane 12:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(pogradec.getId());
                    route.setEndTerminalId(tirana.getId());
                    route.setDuration(2.5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(12, 0));
                    route.setSeats(80);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });
        // 3- Pogradec-Tirane 17:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(pogradec.getId(), tirana.getId(), LocalTime.of(17, 0))
                .map(o -> {
                    log.info("Pogradec-Tirane 17:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(pogradec.getId());
                    route.setEndTerminalId(tirana.getId());
                    route.setDuration(2.5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(17, 0));
                    route.setSeats(50);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });
        // 4- Tirane-Pogradec 09:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(tirana.getId(), pogradec.getId(), LocalTime.of(9, 0))
                .map(o -> {
                    log.info("Tirane-Pogradec 09:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(tirana.getId());
                    route.setEndTerminalId(pogradec.getId());
                    route.setDuration(2.5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(9, 0));
                    route.setSeats(50);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });
        // 5- Tirane-Pogradec 12:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(tirana.getId(), pogradec.getId(), LocalTime.of(12, 0))
                .map(o -> {
                    log.info("Tirane-Pogradec 12:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(tirana.getId());
                    route.setEndTerminalId(pogradec.getId());
                    route.setDuration(2.5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(12, 0));
                    route.setSeats(50);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });

        // 6- Tirane-Pogradec 17:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(tirana.getId(), pogradec.getId(), LocalTime.of(17, 0))
                .map(o -> {
                    log.info("Tirane-Pogradec 17:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(tirana.getId());
                    route.setEndTerminalId(pogradec.getId());
                    route.setDuration(2.5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(17, 0));
                    route.setSeats(20);
                    route.setPrice(600);

                    return routeRepository.save(route);
                });
        // 7- Tirane-Sarande  05:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(tirana.getId(), saranda.getId(), LocalTime.of(5, 0))
                .map(o -> {
                    log.info("Tirane-Sarande 05:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(tirana.getId());
                    route.setEndTerminalId(saranda.getId());
                    route.setDuration(5);
                    route.setDriverId(petriti.getId());
                    route.setStart(LocalTime.of(5, 0));
                    route.setSeats(100);
                    route.setPrice(1300);

                    return routeRepository.save(route);
                });
        // 8- Tirane-Sarande  21:00
        routeRepository.findByStartTerminalIdAndEndTerminalIdAndStart(tirana.getId(), saranda.getId(), LocalTime.of(21, 0))
                .map(o -> {
                    log.info("Tirane-Sarande 21:00 is present");
                    return o;
                }).orElseGet(() -> {
                    Route route = new Route();
                    route.setStartTerminalId(tirana.getId());
                    route.setEndTerminalId(saranda.getId());
                    route.setDuration(5);
                    route.setDriverId(beni.getId());
                    route.setStart(LocalTime.of(21, 0));
                    route.setSeats(100);
                    route.setPrice(1300);

                    return routeRepository.save(route);
                });
    }

    private Terminal createTerminal(String city, String address) {
        Terminal terminal = new Terminal();
        terminal.setCity(city);
        terminal.setAddress(address);
        return terminalRepository.save(terminal);
    }

    private User createUser(String email, String password) {
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        return userRepository.save(user);
    }

    /*private void createRouteIfNotExists(Terminal startTerminal, Terminal endTerminal, User driver, Instant start, double duration, double price, int seats) {
        Route route = new Route();
        route.setStartTerminal(startTerminal);
        route.setEndTerminal(endTerminal);
        route.setDriver(driver);
        route.setStart(start);
        route.setDuration(duration);
        route.setPrice(price);
        route.setSeats(seats);
        // Since there's no 'findBy' logic demonstrated, directly save for demonstration purposes
        routeRepository.save(route);
    }*/
}