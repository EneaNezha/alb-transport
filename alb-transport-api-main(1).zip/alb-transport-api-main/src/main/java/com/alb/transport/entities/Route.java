package com.alb.transport.entities;


import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.Instant;
import java.time.LocalTime;

@Getter
@Setter
@Entity
@Slf4j
@Table(name = "at_route")
public class Route extends BaseEntity {

    @Column(name = "start_terminal_id")
    private int startTerminalId;

    @Column(name = "end_terminal_id")
    private int endTerminalId;

    @Column(name = "driver_id")
    private int driverId;

    @ManyToOne
    @JoinColumn(name = "start_terminal_id", insertable = false, updatable = false)
    private Terminal startTerminal;

    @ManyToOne
    @JoinColumn(name = "end_terminal_id", insertable = false, updatable = false)
    private Terminal endTerminal;

    @ManyToOne
    @JoinColumn(name = "driver_id", insertable = false, updatable = false)
    private User driver;

    @Column(name = "start")
    /*@JsonFormat(pattern = "HH:mm")*/
    @DateTimeFormat(style = "HH:mm")
    private LocalTime start;

    @Column(name = "duration")
    private double duration;

    @Column(name = "price")
    private double price;

    @Column(name  = "seats")
    private int seats;

    @Transient
    public String getTitle() {
        try {
            return startTerminal.getCity() + " - " + endTerminal.getCity();
        }
        catch (Exception ex) {
            log.error("Error create title: ", ex);
        }

        return "N/A";
    }
}
