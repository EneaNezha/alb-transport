package com.alb.transport.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name = "at_terminal")
public class Terminal extends BaseEntity {
    private String city;
    private String address;
}
