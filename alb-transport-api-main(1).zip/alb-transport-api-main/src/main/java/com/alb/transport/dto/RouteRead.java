package com.alb.transport.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalTime;

public interface RouteRead {
    String getId();
    String getStartTerminalId();
    String getStartTerminalCity();
    String getStartTerminalAddress();
    String getEndTerminalId();
    String getEndTerminalCity();
    String getEndTerminalAddress();
    String getDriverId();
    String getDriverPhone();
    String getSeats();
    @JsonFormat(pattern = "HH:mm")
    LocalTime getStart();
    String getDuration();
    String getPrice();
}
