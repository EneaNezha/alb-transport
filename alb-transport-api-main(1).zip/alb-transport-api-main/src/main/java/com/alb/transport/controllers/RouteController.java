package com.alb.transport.controllers;

import com.alb.transport.dto.RouteRead;
import com.alb.transport.entities.Route;
import com.alb.transport.services.RouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/routes")
public class RouteController {
    private final RouteService routeService;

    @Autowired
    public RouteController(RouteService routeService) {
        this.routeService = routeService;
    }

    @GetMapping
    public ResponseEntity<List<Route>> getAllRoutes() {
        List<Route> routes = routeService.findAllRoutes();
        if (routes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(routes);
    }

    @GetMapping("/get-upcoming")
    public List<RouteRead> getUpComing(@RequestParam("city") String from) {
        return routeService.getUpComingByFromRouteName(from);
    }
}