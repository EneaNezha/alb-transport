package com.alb.transport.services;

import com.alb.transport.entities.User;
import com.alb.transport.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Slf4j
@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public void initializeDefaultUsers() {
        Optional<User> first = userRepository.findByEmail("default@example.com");

        if(first.isPresent()) {
            log.info("User with email default@example.com exists!");
        }
        else {
            User defaultUser = new User();
            defaultUser.setEmail("default@example.com");
            defaultUser.setPassword("password123");
            defaultUser.setPhone("123-456-7890");
            userRepository.save(defaultUser);
        }

        Optional<User> second = userRepository.findByEmail("another@example.com");

        if(second.isPresent()) {
            log.info("User with email another@example.com exists!");
        }
        else {
            User anotherUser = new User();
            anotherUser.setEmail("another@example.com");
            anotherUser.setPassword("password456");
            anotherUser.setPhone("098-765-4321");
            userRepository.save(anotherUser);
        }
    }
}
