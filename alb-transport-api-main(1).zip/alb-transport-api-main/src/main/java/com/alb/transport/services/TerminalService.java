package com.alb.transport.services;

import com.alb.transport.entities.Terminal;
import com.alb.transport.repository.TerminalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TerminalService {
    private final TerminalRepository terminalRepository;

    public void initDefaultData() {
        Terminal first = new Terminal();
        first.setCity("Tirana");
        first.setAddress("RR: Terminalit Tirane");
        terminalRepository.getByCity(first.getCity()).orElseGet(() -> terminalRepository.save(first));

        Terminal second = new Terminal();
        second.setCity("Pogradec");
        second.setAddress("RR: Terminalit Pogradec");
        terminalRepository.getByCity(second.getCity()).orElseGet(() -> terminalRepository.save(second));

        Terminal third = new Terminal();
        third.setCity("Saranda");
        third.setAddress("RR: Terminalit Sarande");
        terminalRepository.getByCity(third.getCity()).orElseGet(() -> terminalRepository.save(third));

        Terminal fourth = new Terminal();
        fourth.setCity("Berat");
        fourth.setAddress("RR: Terminalit Berat");
        terminalRepository.getByCity(fourth.getCity()).orElseGet(() -> terminalRepository.save(fourth));

        Terminal fifth = new Terminal();
        fifth.setCity("Vlora");
        fifth.setAddress("RR: Terminalit Vlora");
        terminalRepository.getByCity(fifth.getCity()).orElseGet(() -> terminalRepository.save(fifth));
    }
}
