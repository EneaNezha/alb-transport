package com.alb.transport.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name = "at_user")
public class User extends BaseEntity {
    private String email;
    private String password;
    private String phone;
}
