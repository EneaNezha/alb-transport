package com.alb.transport.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@Entity
@Table(name = "at_booking")
public class Booking extends BaseEntity {
    private int seats;

    private double price;

    @Column(name = "router_id")
    private int routeId;

    @ManyToOne
    @JoinColumn(name = "router_id", insertable = false, updatable = false)
    private Route driver;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "phone")
    private String phone;
}
