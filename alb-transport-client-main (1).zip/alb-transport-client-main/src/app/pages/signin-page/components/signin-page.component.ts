import { Component } from '@angular/core';

@Component({
  selector: 'app-signin-page.component',
  standalone: true,
  imports: [],
  templateUrl: './signin-page.component.html',
  styleUrl: './signin-page.component.css'
})
export class SigninPageComponent {

}
