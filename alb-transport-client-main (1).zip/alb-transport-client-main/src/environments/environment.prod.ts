export const environment = {
  production: true,
  apiBaseUrl: 'http://myip.com'
};
